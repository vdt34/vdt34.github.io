Hello.

If you want to send command manually via ADB, then first open cmd.here
And then copy/paste these commands on command prompt and press Enter Key... 

adb.exe wait-for-device    (This command waits for ADB Authorization on phone)

adb.exe devices            (This command is to check connected ADB Device)

adb.exe shell content insert --uri content://settings/secure --bind name:s:user_setup_complete --bind value:s:1
(This command is to Bypass FRP lock via ADB Interface)

adb.exe reboot             (This command is to Restart phone) or You may Restart with Power button


UUUUUUUU     UUUUUUUU                 PPPPPPPPPPPPPPPPP                                      KKKKKKKKK    KKKKKKK                    NNNNNNNN        NNNNNNNN
U::::::U     U::::::U                 P::::::::::::::::P                                     K:::::::K    K:::::K                    N:::::::N       N::::::N
U::::::U     U::::::U                 P::::::PPPPPP:::::P                                    K:::::::K    K:::::K                    N::::::::N      N::::::N
UU:::::U     U:::::UU                 PP:::::P     P:::::P                                   K:::::::K   K::::::K                    N:::::::::N     N::::::N
 U:::::U     U:::::Unnnn  nnnnnnnn      P::::P     P:::::Paaaaaaaaaaaaa      ccccccccccccccccKK::::::K  K:::::KKK    ccccccccccccccccN::::::::::N    N::::::N
 U:::::D     D:::::Un:::nn::::::::nn    P::::P     P:::::Pa::::::::::::a   cc:::::::::::::::c  K:::::K K:::::K     cc:::::::::::::::cN:::::::::::N   N::::::N
 U:::::D     D:::::Un::::::::::::::nn   P::::PPPPPP:::::P aaaaaaaaa:::::a c:::::::::::::::::c  K::::::K:::::K     c:::::::::::::::::cN:::::::N::::N  N::::::N
 U:::::D     D:::::Unn:::::::::::::::n  P:::::::::::::PP           a::::ac:::::::cccccc:::::c  K:::::::::::K     c:::::::cccccc:::::cN::::::N N::::N N::::::N
 U:::::D     D:::::U  n:::::nnnn:::::n  P::::PPPPPPPPP      aaaaaaa:::::ac::::::c     ccccccc  K:::::::::::K     c::::::c     cccccccN::::::N  N::::N:::::::N
 U:::::D     D:::::U  n::::n    n::::n  P::::P            aa::::::::::::ac:::::c               K::::::K:::::K    c:::::c             N::::::N   N:::::::::::N
 U:::::D     D:::::U  n::::n    n::::n  P::::P           a::::aaaa::::::ac:::::c               K:::::K K:::::K   c:::::c             N::::::N    N::::::::::N
 U::::::U   U::::::U  n::::n    n::::n  P::::P          a::::a    a:::::ac::::::c     cccccccKK::::::K  K:::::KKKc::::::c     cccccccN::::::N     N:::::::::N
 U:::::::UUU:::::::U  n::::n    n::::nPP::::::PP        a::::a    a:::::ac:::::::cccccc:::::cK:::::::K   K::::::Kc:::::::cccccc:::::cN::::::N      N::::::::N
  UU:::::::::::::UU   n::::n    n::::nP::::::::P        a:::::aaaa::::::a c:::::::::::::::::cK:::::::K    K:::::K c:::::::::::::::::cN::::::N       N:::::::N
    UU:::::::::UU     n::::n    n::::nP::::::::P         a::::::::::aa:::a cc:::::::::::::::cK:::::::K    K:::::K  cc:::::::::::::::cN::::::N        N::::::N
      UUUUUUUUU       nnnnnn    nnnnnnPPPPPPPPPP          aaaaaaaaaa  aaaa   ccccccccccccccccKKKKKKKKK    KKKKKKK    ccccccccccccccccNNNNNNNN         NNNNNNN
 -==ThE LeGenD NeVeR Die==--==ThE LeGenD NeVeR Die==--==ThE LeGenD NeVeR Die==--==ThE LeGenD NeVeR Die==--==ThE LeGenD NeVeR Die==--==ThE LeGenD NeVeR Die==-  

Elcomsoft Phone Password Breaker v10.12.38835.Cracked.by.yoza[UpK]
==================================================================
 
Software name : Elcomsoft Phone Password Breaker
Version	      : 10.12.38835
Last Update   : 10 February, 2023
Release Type  : Forensics Edition             
OS            : Windows 7/8/9/10/11 x32/x64
Developer     : Elcomsoft Co., Ltd.
Web-site      : www.elcomsoft.com

The author is not responsible for the bad usage of this product.
This is for EDUCATIONAL AND EVALUATION PURPOSES ONLY.
Use at your own risk.
If you like this program, please support the developer and buy it !!

Instruction :
=============
1) Extract rar file.
2) Run Setup file : eppb_setup_en.msi
3) Replace "wbxml2.dll" installed folder ("C:\Program Files (x86)\Elcomsoft Password Recovery\Elcomsoft Phone Password Breaker")
   with "wbxml2.dll" provide on crack folder.
4) Run the Application.
5) Done!

That's all falks!

Have fun....

Best regards,
-=yoza=-

Greetz to :
 - fly
 - FSLove
 - Lightning Wolf
 - ZeNiX  
 - davis7
 - freecat
 - GUC
 - peterchen
 - Sound
 - XiMo
 - Hmily
 - natyou
 - Verol
 - mdj
 - TechLord
 - All [RET/LCG/CCG/UpK]'ers that can't be mentioned one by one.
 - All friends at ExeTools forum.
 - All who work hard help make the scene secure!